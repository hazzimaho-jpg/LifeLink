/* ============================================================
   LifeLink Cloud Functions
   - adminLogin: checks the admin password (kept server-side only)
     and issues a Firebase custom token with an `admin: true` claim.
   - geminiChat: proxies chatbot messages to the Gemini API so the
     API key is never exposed to the browser.

   Secrets (set once, before deploying):
     firebase functions:secrets:set ADMIN_PASSWORD
     firebase functions:secrets:set GEMINI_API_KEY
   ============================================================ */

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();

const ADMIN_PASSWORD = defineSecret("ADMIN_PASSWORD");
const GEMINI_API_KEY = defineSecret("GEMINI_API_KEY");

// Bump this if Google deprecates the model — see https://ai.google.dev/gemini-api/docs/models
const GEMINI_MODEL = "gemini-3.6-flash";

const SYSTEM_INSTRUCTION = `You are the LifeLink Assistant, a friendly helper for a community
platform called LifeLink. LifeLink connects people to local service providers (plumbers,
electricians, tutors, cleaners, etc.), a community map, live healthcare facility data, weather,
and community alerts (crime, fraud, news). Help users find services, understand alerts, learn
how to leave reviews, message providers on WhatsApp, or become a provider themselves. Keep
answers concise (2-4 sentences), warm, and practical. If asked about something unrelated to
LifeLink or local community needs, answer briefly and redirect gently back to how LifeLink
can help.`;

// ---------- Admin login ----------
exports.adminLogin = onCall({ secrets: [ADMIN_PASSWORD] }, async (request) => {
  const { password } = request.data || {};
  if (typeof password !== "string" || !password) {
    throw new HttpsError("invalid-argument", "Password is required.");
  }
  if (password !== ADMIN_PASSWORD.value()) {
    throw new HttpsError("permission-denied", "Incorrect admin password.");
  }
  const token = await admin.auth().createCustomToken("lifelink-admin", { admin: true });
  return { token };
});

// ---------- Gemini-powered chatbot ----------
exports.geminiChat = onCall({ secrets: [GEMINI_API_KEY] }, async (request) => {
  const { message, history } = request.data || {};
  if (typeof message !== "string" || !message.trim()) {
    throw new HttpsError("invalid-argument", "A message is required.");
  }

  const contents = (Array.isArray(history) ? history : [])
    .slice(-10) // keep the request small
    .map((h) => ({
      role: h.role === "user" ? "user" : "model",
      parts: [{ text: String(h.text || "") }],
    }));
  contents.push({ role: "user", parts: [{ text: message }] });

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY.value()}`;

  let resp;
  try {
    resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents,
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
        generationConfig: { maxOutputTokens: 300, temperature: 0.6 },
      }),
    });
  } catch (err) {
    console.error("Network error calling Gemini:", err);
    throw new HttpsError("unavailable", "Could not reach Gemini API.");
  }

  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    console.error("Gemini API error:", resp.status, errText);
    throw new HttpsError("internal", "Gemini API request failed.");
  }

  const data = await resp.json();
  const reply =
    data?.candidates?.[0]?.content?.parts?.map((p) => p.text).join("").trim() ||
    "Sorry, I couldn't come up with a response just now — please try rephrasing.";

  return { reply };
});
