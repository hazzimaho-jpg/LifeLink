/* ============================================================
   LifeLink App Core — Firebase Edition
   Auth: Firebase Authentication (email/password)
   Data: Cloud Firestore
   Admin auth + Gemini chatbot: Cloud Functions (js/../functions)
   ============================================================ */

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, updateProfile as fbUpdateProfile,
  signInWithCustomToken, getIdTokenResult,
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import {
  getFirestore, doc, setDoc, getDoc, updateDoc, deleteDoc,
  collection, addDoc, getDocs, query, where, orderBy, serverTimestamp,
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";
import {
  getFunctions, httpsCallable,
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-functions.js";

import { firebaseConfig, FUNCTIONS_REGION } from "../firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const fns = getFunctions(app, FUNCTIONS_REGION);

// ---------- auth-ready plumbing ----------
let _authUser = null;
let _resolveAuthReady;
const authReady = new Promise((res) => { _resolveAuthReady = res; });

onAuthStateChanged(auth, (user) => {
  _authUser = user;
  _resolveAuthReady(user);
  refreshAuthUI();
});

function waitForAuth() {
  return authReady;
}

// ---------- users / auth ----------
async function registerUser({ name, email, password, phone }) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  await fbUpdateProfile(cred.user, { displayName: name });
  await setDoc(doc(db, "users", cred.user.uid), {
    name, email, phone: phone || "", createdAt: serverTimestamp(),
  });
  return cred.user;
}

async function loginUser(email, password) {
  const cred = await signInWithEmailAndPassword(auth, email, password);
  return cred.user;
}

async function logoutUser() {
  await signOut(auth);
}

async function currentUserProfile() {
  await waitForAuth();
  if (!_authUser) return null;
  const snap = await getDoc(doc(db, "users", _authUser.uid));
  if (!snap.exists()) return null;
  return { id: _authUser.uid, email: _authUser.email, ...snap.data() };
}

async function updateUserProfile(uid, patch) {
  await updateDoc(doc(db, "users", uid), patch);
}

async function getAllUsers() {
  const snap = await getDocs(collection(db, "users"));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

// ---------- admin (separate password, via Cloud Function + custom token) ----------
async function adminLogin(password) {
  const callAdminLogin = httpsCallable(fns, "adminLogin");
  const result = await callAdminLogin({ password });
  await signInWithCustomToken(auth, result.data.token);
}

async function adminLogout() {
  await signOut(auth);
}

async function isAdmin() {
  await waitForAuth();
  if (!_authUser) return false;
  const tokenResult = await getIdTokenResult(_authUser, true);
  return !!tokenResult.claims.admin;
}

async function guardAdmin() {
  const ok = await isAdmin();
  if (!ok) window.location.href = "admin-login.html";
  return ok;
}

// ---------- providers ----------
async function getProviders() {
  const snap = await getDocs(collection(db, "providers"));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}
async function getProvider(id) {
  const snap = await getDoc(doc(db, "providers", id));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}
async function addProvider(data) {
  const ref = await addDoc(collection(db, "providers"), { verified: false, createdAt: serverTimestamp(), ...data });
  return { id: ref.id, ...data };
}
async function updateProvider(id, patch) {
  await updateDoc(doc(db, "providers", id), patch);
}
async function deleteProvider(id) {
  await deleteDoc(doc(db, "providers", id));
}

// ---------- become-a-provider requests ----------
async function submitProviderRequest(data) {
  const ref = await addDoc(collection(db, "providerRequests"), {
    status: "pending", submittedAt: serverTimestamp(), ...data,
  });
  return { id: ref.id, ...data };
}
async function getProviderRequests() {
  const snap = await getDocs(collection(db, "providerRequests"));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}
async function getProviderRequestsForEmail(email) {
  const q = query(collection(db, "providerRequests"), where("email", "==", email));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}
async function approveProviderRequest(id) {
  const reqSnap = await getDoc(doc(db, "providerRequests", id));
  if (!reqSnap.exists()) return null;
  const req = reqSnap.data();
  await updateDoc(doc(db, "providerRequests", id), { status: "approved" });
  return addProvider({
    name: req.businessName, category: req.category, description: req.description,
    phone: req.phone, area: req.area, verified: false,
  });
}
async function rejectProviderRequest(id) {
  await updateDoc(doc(db, "providerRequests", id), { status: "rejected" });
}

// ---------- reviews ----------
async function getReviews(providerId) {
  const q = query(collection(db, "reviews"), where("providerId", "==", providerId));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
    .sort((a, b) => (b.date?.toMillis?.() ?? 0) - (a.date?.toMillis?.() ?? 0));
}
async function addReview(providerId, { name, rating, comment }) {
  const ref = await addDoc(collection(db, "reviews"), {
    providerId, name, rating, comment, date: serverTimestamp(),
  });
  return { id: ref.id, providerId, name, rating, comment, date: new Date() };
}
async function averageRating(providerId) {
  const reviews = await getReviews(providerId);
  if (!reviews.length) return 0;
  return reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
}

// ---------- alerts ----------
async function getAlerts() {
  const snap = await getDocs(collection(db, "alerts"));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
    .sort((a, b) => (b.date?.toMillis?.() ?? 0) - (a.date?.toMillis?.() ?? 0));
}
async function addAlert(data) {
  const ref = await addDoc(collection(db, "alerts"), { date: serverTimestamp(), ...data });
  return { id: ref.id, ...data };
}
async function deleteAlert(id) {
  await deleteDoc(doc(db, "alerts", id));
}

// ---------- Gemini-powered chatbot ----------
async function chatWithGemini(message, history) {
  const callGeminiChat = httpsCallable(fns, "geminiChat");
  const result = await callGeminiChat({ message, history: history || [] });
  return result.data.reply;
}

// ---------- WhatsApp handoff ----------
function whatsappLink(phone, message) {
  const cleanPhone = String(phone).replace(/[^0-9]/g, "");
  const defaultMsg = message || "Hello, I got your contact from LifeLink.";
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(defaultMsg)}`;
}

// ---------- helpers ----------
function starString(rating) {
  const full = Math.round(rating);
  return "★".repeat(full) + "☆".repeat(5 - full);
}
function timeAgo(dateVal) {
  const ms = dateVal?.toMillis ? dateVal.toMillis() : new Date(dateVal).getTime();
  const diffMs = Date.now() - ms;
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}
function toast(msg) {
  let el = document.getElementById("ll-toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "ll-toast";
    el.className = "toast";
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("show"), 2600);
}

// ---------- nav helpers (auth-aware UI) ----------
function refreshAuthUI() {
  const user = _authUser;
  document.querySelectorAll("[data-auth='in']").forEach((el) => (el.style.display = user ? "" : "none"));
  document.querySelectorAll("[data-auth='out']").forEach((el) => (el.style.display = user ? "none" : ""));
  document.querySelectorAll("[data-user='name']").forEach((el) => { if (user) el.textContent = user.displayName || user.email; });
}

function initNav() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => nav.classList.toggle("open"));
  }
  const path = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".main-nav a").forEach((a) => {
    if (a.getAttribute("href") === path) a.classList.add("active");
  });
  refreshAuthUI();
}

function registerServiceWorker() {
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("service-worker.js").catch(() => {});
    });
  }
}

document.addEventListener("DOMContentLoaded", initNav);
registerServiceWorker();

export const LL = {
  auth, db,
  waitForAuth,
  registerUser, loginUser, logoutUser, currentUserProfile, updateUserProfile, getAllUsers,
  adminLogin, adminLogout, isAdmin, guardAdmin,
  getProviders, getProvider, addProvider, updateProvider, deleteProvider,
  submitProviderRequest, getProviderRequests, getProviderRequestsForEmail, approveProviderRequest, rejectProviderRequest,
  getReviews, addReview, averageRating,
  getAlerts, addAlert, deleteAlert,
  chatWithGemini,
  whatsappLink, starString, timeAgo, toast, refreshAuthUI,
};

// Expose globally too, so onclick="" handlers in markup (e.g. admin.html) can reach it.
window.LL = LL;
