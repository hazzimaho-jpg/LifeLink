/* ============================================================
   LifeLink Chatbot Assistant
   Primary: Gemini API via the "geminiChat" Cloud Function
   (keeps your Gemini API key secret on the server).
   Fallback: simple rule-based answers if the call fails
   (e.g. Firebase not configured yet, or offline).
   ============================================================ */

import { LL } from "./app.js";

const RULES = [
  { keys: ["hi", "hello", "hey"], reply: "Hi there! I'm the LifeLink assistant. I can help you find services, report an issue, or explain how LifeLink works." },
  { keys: ["service", "plumber", "electrician", "provider", "find"], reply: "You can browse verified local providers on the Local Services page. Want me to take you there?", link: { text: "Open Local Services", href: "services.html" } },
  { keys: ["report", "issue", "problem", "crime", "alert"], reply: "You can view community alerts and safety reports on the Alerts page. If it's urgent, please also contact local authorities directly.", link: { text: "View Alerts", href: "alerts.html" } },
  { keys: ["become", "provider", "sign up as", "register business"], reply: "To offer your services on LifeLink, fill out the Become a Provider form and our team will review your submission.", link: { text: "Become a Provider", href: "become-provider.html" } },
  { keys: ["weather"], reply: "You can see the current local weather forecast right on the home page dashboard.", link: { text: "Go to Home", href: "index.html" } },
  { keys: ["health", "hospital", "clinic", "doctor"], reply: "The Healthcare page lists nearby hospitals and clinics using live location data.", link: { text: "Open Healthcare", href: "healthcare.html" } },
  { keys: ["review", "rating"], reply: "Open any provider's profile page from Local Services — you'll find a 'Leave a review' form near the bottom." },
  { keys: ["contact", "whatsapp", "message provider"], reply: "On each provider's page there's a 'Message on WhatsApp' button that opens a prefilled chat for you." },
  { keys: ["login", "sign in", "account"], reply: "You can log in or create an account from the Login page, top right of the navigation.", link: { text: "Go to Login", href: "login.html" } },
  { keys: ["admin"], reply: "Admin access is separate from user accounts and requires the admin password on the Admin Login page." },
  { keys: ["thank", "thanks"], reply: "You're welcome! Let me know if there's anything else I can help you find." },
];
const FALLBACK = "I'm not totally sure about that yet, but you can explore Local Services, Healthcare, Map, or Alerts from the menu — or try rephrasing your question.";

function ruleAnswerFor(text) {
  const t = text.toLowerCase();
  for (const rule of RULES) {
    if (rule.keys.some((k) => t.includes(k))) return rule;
  }
  return { reply: FALLBACK };
}

function buildWidget() {
  const launcher = document.createElement("button");
  launcher.id = "lifelink-chat-launcher";
  launcher.setAttribute("aria-label", "Open LifeLink assistant");
  launcher.innerHTML = "💬";

  const panel = document.createElement("div");
  panel.id = "lifelink-chat-panel";
  panel.innerHTML = `
    <div class="chat-header">
      <span>LifeLink Assistant</span>
      <button id="ll-chat-close" aria-label="Close chat">✕</button>
    </div>
    <div class="chat-body" id="ll-chat-body"></div>
    <div class="chat-suggestions" id="ll-chat-suggestions">
      <button class="chip" data-q="Find a service">Find a service</button>
      <button class="chip" data-q="Report an issue">Report an issue</button>
      <button class="chip" data-q="Become a provider">Become a provider</button>
    </div>
    <div class="chat-input-row">
      <input id="ll-chat-input" type="text" placeholder="Ask me something..." />
      <button id="ll-chat-send">Send</button>
    </div>
  `;

  document.body.appendChild(launcher);
  document.body.appendChild(panel);

  const body = panel.querySelector("#ll-chat-body");
  const history = []; // [{role: "user"|"model", text}]

  function addMsg(text, who, link) {
    const div = document.createElement("div");
    div.className = `chat-msg ${who}`;
    div.textContent = text;
    body.appendChild(div);
    if (link) {
      const a = document.createElement("a");
      a.href = link.href;
      a.textContent = link.text;
      a.style.display = "block";
      a.style.marginTop = "4px";
      a.style.fontWeight = "700";
      a.style.color = "var(--color-primary-dark)";
      body.appendChild(a);
    }
    body.scrollTop = body.scrollHeight;
  }

  function addTyping() {
    const div = document.createElement("div");
    div.className = "chat-msg bot";
    div.id = "ll-chat-typing";
    div.textContent = "…";
    body.appendChild(div);
    body.scrollTop = body.scrollHeight;
  }
  function removeTyping() {
    document.getElementById("ll-chat-typing")?.remove();
  }

  async function respond(text) {
    addMsg(text, "user");
    history.push({ role: "user", text });
    addTyping();
    try {
      const reply = await LL.chatWithGemini(text, history.slice(-10, -1));
      removeTyping();
      addMsg(reply, "bot");
      history.push({ role: "model", text: reply });
    } catch (err) {
      // Gemini/Cloud Function unavailable (e.g. Firebase not configured yet) — fall back to rules
      removeTyping();
      const rule = ruleAnswerFor(text);
      addMsg(rule.reply, "bot", rule.link);
    }
  }

  launcher.addEventListener("click", () => {
    panel.classList.toggle("open");
    if (panel.classList.contains("open") && !body.dataset.greeted) {
      addMsg("Hi! I'm your LifeLink assistant. Ask me about local services, alerts, healthcare, or how to become a provider.", "bot");
      body.dataset.greeted = "1";
    }
  });
  panel.querySelector("#ll-chat-close").addEventListener("click", () => panel.classList.remove("open"));

  panel.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => respond(chip.dataset.q));
  });

  const input = panel.querySelector("#ll-chat-input");
  panel.querySelector("#ll-chat-send").addEventListener("click", () => {
    if (input.value.trim()) { respond(input.value.trim()); input.value = ""; }
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && input.value.trim()) { respond(input.value.trim()); input.value = ""; }
  });
}

document.addEventListener("DOMContentLoaded", buildWidget);
